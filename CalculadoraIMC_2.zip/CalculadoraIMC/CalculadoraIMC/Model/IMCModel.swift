//
//  IMCModel.swift
//  CalculadoraIMC
//
//  Created by user208023 on 5/18/22.
//

import Foundation

struct Categoria {
    var categoria: String
    var imagem: String
}

    

