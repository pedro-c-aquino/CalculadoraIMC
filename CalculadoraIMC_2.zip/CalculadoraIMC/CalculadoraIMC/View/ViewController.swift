//
//  ViewController.swift
//  CalculadoraIMC
//
//  Created by user208023 on 5/18/22.
//

import UIKit

class ViewController: UIViewController {
    
    

    @IBOutlet weak var weightTextField: UITextField!
    @IBOutlet weak var heightTextField: UITextField!
    @IBOutlet weak var resultView: UIView!
    @IBOutlet weak var resultImageView: UIImageView!
    @IBOutlet weak var IMCLabel: UILabel!
    @IBOutlet weak var categoryLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        resultView.isHidden = true
        
    }
    
    
    
    @IBAction func calculateButton(_ sender: UIButton) {
        
        let imcController = IMCController()
        
       let imc = imcController.calculateIMC(height: Double(self.heightTextField.text ?? "") ?? 0.0, weight: Double(self.weightTextField.text ?? "") ?? 0.0)

        IMCLabel.text = String(format: "%.2f", imc)

        let categoria = imcController.categoriaIMC(imc: imc)

        resultImageView.image = UIImage(named: categoria.imagem)

        categoryLabel.text = categoria.categoria

        resultView.isHidden = false
    }
    

}

